﻿namespace Domain.Model
{
    public class Profesor
    {
        public string nombre_y_apellido { get; set; }
        public string mail { get; set; }
        public string telefono { get; set; }
        public int id { get; set; }
        public string contraseña { get; set; }
    }
}